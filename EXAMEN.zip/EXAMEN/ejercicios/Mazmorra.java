﻿import java.util.Random;
import java.util.Scanner;

/** La Mazmorra Infinita: una aventura con tesoros y sorpresas. */
public class Mazmorra {
    private static final Scanner SC = new Scanner(System.in);
    private static final Random AZAR = new Random();
    private static final char VACIO='.', JUGADOR='P', ENEMIGO='E', ELITE='L', TRAMPA='X', TRAMPA_AV='A',
            COFRE='C', CURACION='H', COMERCIANTE='M', ACERTIJO='?', OBSTACULO='#', LLAVE='K', TESORO='$';

    private static int vidasIniciales=4, tamano=8;
    private static String dificultad="Normal";
    private static char[][] mapa;
    private static boolean[][] visitadas;
    private static int fila, columna, vidas, oro, pociones, veneno, turnosVeneno;
    private static boolean tieneLlave, pistaDisponible, escudo, gano;

    /** Enseña el menú principal y abre la opción que elija el jugador. */
    public static void main(String[] args) {
        boolean salir=false;
        while (!salir) {
            System.out.println("\n=== LA MAZMORRA INFINITA ===\n1. Nueva Partida\n2. Configuracion\n3. Instrucciones\n4. Creditos\n5. Salir");
            try {
                int op=leerEntero("Seleccione una opcion: ",1,5);
                switch(op) {
                    case 1: jugar(); break;
                    case 2: configuracion(); break;
                    case 3: instrucciones(); break;
                    case 4: System.out.println("\nJuego diseñado por David Tribiño."); break;
                    case 5: salir=true; System.out.println("¡Hasta la proxima aventura!"); break;
                    default: throw new OpcionInvalidaException("Opcion inexistente.");
                }
            } catch (OpcionInvalidaException e) { System.out.println(e.getMessage()); }
        }
        SC.close();
    }

    /** Pide un número y comprueba que esté dentro del rango permitido. */
    private static int leerEntero(String mensaje,int min,int max) {
        while(true) {
            System.out.print(mensaje);
            String linea=SC.nextLine().trim();
            try {
                int n=Integer.parseInt(linea);
                if(n<min||n>max) throw new OpcionInvalidaException("Elige un numero entre "+min+" y "+max+".");
                return n;
            } catch(NumberFormatException e) { System.out.println("Entrada invalida: escribe un numero."); }
              catch(OpcionInvalidaException e) { System.out.println(e.getMessage()); }
        }
    }

    /** Deja elegir las vidas, el tamaño del mapa y la dificultad. */
    private static void configuracion() {
        System.out.println("\n--- CONFIGURACION ---");
        vidasIniciales=leerEntero("Vidas iniciales (3-5): ",3,5);
        int t=leerEntero("Tamano: 1) 6x6  2) 8x8  3) 10x10: ",1,3);
        tamano=t==1?6:t==2?8:10;
        int d=leerEntero("Dificultad: 1) Facil  2) Normal  3) Dificil: ",1,3);
        dificultad=d==1?"Facil":d==2?"Normal":"Dificil";
        System.out.println("Configuracion guardada: "+vidasIniciales+" vidas, "+tamano+"x"+tamano+", "+dificultad+".");
    }

    /** Muestra cómo jugar y qué hace cada evento que puede aparecer. */
    private static void instrucciones() {
        System.out.println("\n--- INSTRUCCIONES ---"
                +"\nCONTROLES"
                +"\nW: moverte hacia arriba."
                +"\nS: moverte hacia abajo."
                +"\nA: moverte hacia la izquierda."
                +"\nD: moverte hacia la derecha."
                +"\n5: consultar vidas, oro, pociones, llave y posicion."
                +"\n6: usar una pocion para recuperar hasta 3 vidas; no supera tus vidas iniciales."
                +"\n7: abandonar la partida."
                +"\n\nEVENTOS Y OBJETOS"
                +"\nLos eventos y obstaculos estan ocultos: en el tablero solo ves tu posicion (P) y puntos (.)."
                +"\nEnemigo (E): pulsa 1 para combatir. Sale un numero del 1 al 10; con 5-10 ganas oro y lo derrotas. Con 1-4 pierdes una vida y el enemigo permanece."
                +"\nEnemigo elite (L): funciona igual, pero da mas oro al derrotarlo."
                +"\nTrampa (X): quita 1 vida en Facil, 2 en Normal y 3 en Dificil. Trampa avanzada (A): recibes de 1 a 4 puntos de dano y puedes quedar envenenado; el veneno quita 1 vida por turno durante 3 turnos."
                +"\nCuracion (H): recuperas hasta 2 vidas, sin superar el maximo inicial."
                +"\nCofre (C): puede contener de 10 a 30 monedas, una pocion, un escudo, una trampa que quita hasta 2 vidas o estar vacio."
                +"\nComerciante (M): 1 compra una pocion por 10 monedas; 2 compra un escudo por 15; 3 compra una pista por 8; 4 no compra nada. El escudo reduce en 2 el siguiente dano."
                +"\nAcertijo (?): responde 2 para acertar y ganar oro; si fallas, pierdes una vida."
                +"\nLlave Mistica (K): es necesaria para abrir el Tesoro Supremo. Tesoro ($): ganas la partida si ya tienes la llave; si no, queda sellado."
                +"\nObstaculo (#): bloquea el paso. Casilla vacia (.): no contiene ningun evento."
                +"\n\nLa dificultad cambia la cantidad de enemigos y trampas. Puedes configurar las vidas iniciales y el tamano del mapa en Configuracion.");
    }

    /** Empieza las partidas y gestiona cada turno hasta ganar, perder o salir. */
    private static void jugar() {
        boolean otra=true;
        while(otra) {
            nuevaPartida();
            String finalPartida="";
            while(vidas>0 && finalPartida.isEmpty()) {
                mostrarMapa(); mostrarEstado();
                System.out.println("\n=== ACCIONES ===\nW. Mover arriba\nS. Mover abajo\nA. Mover izquierda\nD. Mover derecha\n5. Ver estado del jugador\n6. Usar objeto/curacion\n7. Abandonar partida");
                String accion=SC.nextLine().trim().toLowerCase();
                try {
                    switch(accion) {
                        case "w": mover(-1,0); break;
                        case "s": mover(1,0); break;
                        case "a": mover(0,-1); break;
                        case "d": mover(0,1); break;
                        case "5": mostrarEstado(); break;
                        case "6": usarObjeto(); break;
                        case "7": finalPartida="abandono"; break;
                        default: throw new OpcionInvalidaException("Accion no valida. Usa W, S, A, D, 5, 6 o 7.");
                    }
                } catch(MovimientoInvalidoException|ObjetoNoDisponibleException|OpcionInvalidaException e) {
                    System.out.println(e.getMessage());
                }
                actualizarEstados();
                if(vidas<=0) finalPartida="derrota";
                if(gano) finalPartida="victoria";
            }
            if(finalPartida.equals("victoria")) System.out.println("\n¡VICTORIA! Has encontrado el Tesoro Supremo con la Llave Mistica. Oro: "+oro+".");
            else if(finalPartida.equals("derrota")) System.out.println("\nDERROTA: te has quedado sin vidas.");
            else System.out.println("\nHas abandonado la mazmorra. Oro conseguido: "+oro+".");
            otra=leerEntero("¿Desea jugar otra vez? 1. Si  2. No: ",1,2)==1;
        }
    }

    /** Prepara un mapa nuevo y reinicia los objetos y el estado del jugador. */
    private static void nuevaPartida() {
        mapa=new char[tamano][tamano]; visitadas=new boolean[tamano][tamano];
        for(int f=0;f<tamano;f++) for(int c=0;c<tamano;c++) mapa[f][c]=VACIO;
        // El tablero parte de una posicion central, como en el codigo de TableroPuntos.
        fila=tamano/2; columna=tamano/2;
        vidas=vidasIniciales; oro=0; pociones=1; veneno=0; turnosVeneno=0; tieneLlave=false; pistaDisponible=false; escudo=false; gano=false;
        colocarEventos(); visitadas[fila][columna]=true;
        System.out.println("\nNueva mazmorra generada: "+tamano+"x"+tamano+", dificultad "+dificultad+".");
    }

    /** Coloca los eventos en el mapa y deja el tesoro lejos del punto de inicio. */
    private static void colocarEventos() {
        poner(LLAVE,1); poner(TESORO,1);
        int factor=dificultad.equals("Facil")?1:dificultad.equals("Dificil")?3:2;
        poner(ENEMIGO,3*factor); poner(ELITE,factor); poner(TRAMPA,3*factor); poner(TRAMPA_AV,factor);
        poner(COFRE,3); poner(CURACION,2); poner(COMERCIANTE,2); poner(ACERTIJO,2); poner(OBSTACULO,Math.max(2,tamano/2));
    }
    /** Busca casillas libres para colocar la cantidad indicada de un evento. */
    private static void poner(char tipo,int cantidad) {
        int intentos=0;
        while(cantidad>0 && intentos++<tamano*tamano*20) {
            int f=AZAR.nextInt(tamano),c=AZAR.nextInt(tamano);
            if(mapa[f][c]==VACIO && !(f==fila&&c==columna) && (tipo!=TESORO || distancia(f,c)>tamano/2)) { mapa[f][c]=tipo; cantidad--; }
        }
    }
    /** Calcula cuántos pasos separan una casilla del jugador. */
    private static int distancia(int f,int c){return Math.abs(f-fila)+Math.abs(c-columna);}

    /** Muestra el mapa ocultando los eventos que hay en cada casilla. */
    private static void mostrarMapa() {
        System.out.println("\n--- MAZMORRA (eventos ocultos) ---");
        for(int f=0;f<tamano;f++) {
            for(int c=0;c<tamano;c++) {
                // Solo se muestra la posicion del jugador; el contenido de cada celda permanece secreto.
                char x=(f==fila&&c==columna)?JUGADOR:VACIO;
                System.out.print(x+" ");
            }
            System.out.println();
        }
    }
    /** Muestra el mapa con todos sus eventos. */
    private static void mostrarMapaFinal() {
        System.out.println("--- MAPA REVELADO ---");
        for(int f=0;f<tamano;f++){ for(int c=0;c<tamano;c++) System.out.print((f==fila&&c==columna?JUGADOR:mapa[f][c])+" "); System.out.println(); }
    }
    /** Enseña las vidas, el oro, los objetos y la posición del jugador. */
    private static void mostrarEstado() {
        System.out.println("Vidas: "+vidas+"/"+vidasIniciales+" | Oro: "+oro+" | Pociones: "+pociones+
                " | Llave: "+(tieneLlave?"si":"no")+" | Posicion: ("+(fila+1)+","+(columna+1)+")"+
                (veneno>0?" | VENENO ("+veneno+" turnos)":"")+(escudo?" | ESCUDO activo":""));
    }

    /** Comprueba si el jugador puede avanzar y resuelve lo que encuentra al llegar. */
    private static void mover(int df,int dc) throws MovimientoInvalidoException {
        int nf=fila+df,nc=columna+dc;
        if(nf<0||nf>=tamano||nc<0||nc>=tamano) throw new MovimientoInvalidoException("No puedes salir del mapa.");
        if(mapa[nf][nc]==OBSTACULO) throw new MovimientoInvalidoException("Un obstaculo bloquea el camino.");
        fila=nf; columna=nc; visitadas[fila][columna]=true; procesarEvento();
    }

    /** Resuelve el evento de la casilla y la deja vacía cuando corresponde. */
    private static void procesarEvento() {
        char e=mapa[fila][columna];
        boolean eliminarEvento=true;
        switch(e) {
            case ENEMIGO:
            case ELITE:
                eliminarEvento=combateEnemigo(e==ELITE);
                break;
            case TRAMPA: int danoTrampa=danioTrampaPorDificultad(); recibirDano(danoTrampa); System.out.println("¡Trampa! Pierdes "+danoTrampa+" vida(s) en dificultad "+dificultad+"."); break;
            case TRAMPA_AV: int variable=1+AZAR.nextInt(4); recibirDano(variable); if(AZAR.nextBoolean()){veneno=3;System.out.println("Trampa avanzada: "+variable+" de dano y veneno durante 3 turnos.");} else System.out.println("Trampa avanzada: "+variable+" de dano."); break;
            case CURACION: int antes=vidas; vidas=Math.min(vidasIniciales,vidas+2); System.out.println("Fuente curativa: recuperas "+(vidas-antes)+" vidas."); break;
            case COFRE: abrirCofre(); break;
            case COMERCIANTE: comerciante(); break;
            case ACERTIJO: acertijo(); break;
            case LLAVE: tieneLlave=true; System.out.println("¡Has obtenido la Llave Mistica!"); break;
            case TESORO: if(tieneLlave) { System.out.println("¡El Tesoro Supremo esta aqui!"); gano=true; } else System.out.println("Encuentras el Tesoro Supremo, pero esta sellado. Busca la Llave Mistica."); break;
            case VACIO: System.out.println("La casilla esta vacia."); break;
            default: break;
        }
        if(eliminarEvento && e!=OBSTACULO && e!=TESORO) mapa[fila][columna]=VACIO;
    }

    /** Simula el combate con un número al azar y da oro si el jugador gana. */
    private static boolean combateEnemigo(boolean elite) {
        System.out.println(elite?"¡Te has encontrado con un enemigo elite!":"¡Te has encontrado con un enemigo!");
        leerEntero("Pulsa 1 para luchar: ",1,1);
        int resultado=AZAR.nextInt(10)+1;
        System.out.println("Ha salido el numero "+resultado+".");
        if(resultado>=5) {
            int recompensa=elite?15+AZAR.nextInt(16):5+AZAR.nextInt(11);
            oro+=recompensa;
            System.out.println("¡Has derrotado al enemigo! Ganas "+recompensa+" monedas de oro.");
            return true;
        }
        vidas=Math.max(0,vidas-1);
        System.out.println("No has podido derrotar al enemigo. Pierdes una vida y el enemigo sigue ahi.");
        return false;
    }

    /** Decide cuánto daño hace una trampa según la dificultad. */
    private static int danioTrampaPorDificultad() {
        if(dificultad.equals("Facil")) return 1;
        if(dificultad.equals("Dificil")) return 3;
        return 2;
    }

    /** Decide al azar qué premio o sorpresa sale del cofre. */
    private static void abrirCofre() {
        int premio=AZAR.nextInt(5);
        switch(premio) {
            case 0: int dinero=10+AZAR.nextInt(21); oro+=dinero; System.out.println("Cofre: encuentras "+dinero+" monedas."); break;
            case 1: pociones++; System.out.println("Cofre: encuentras una pocion."); break;
            case 2: escudo=true; System.out.println("Cofre: encuentras un escudo que reduce el proximo dano."); break;
            case 3: recibirDano(2); System.out.println("¡Trampa oculta en el cofre! Pierdes hasta 2 vidas."); break;
            default: System.out.println("El cofre esta vacio.");
        }
    }
    /** Deja comprar objetos o una pista usando el oro conseguido. */
    private static void comerciante() {
        System.out.println("\nComerciante: Oro disponible: "+oro+"\n1. Pocion (10 oro)\n2. Escudo temporal (15 oro)\n3. Pista del mapa (8 oro)\n4. Nada");
        int op=leerEntero("Compra: ",1,4);
        if(op==1) comprar(10,"pocion");
        else if(op==2) comprar(15,"escudo");
        else if(op==3) { if(oro<8) System.out.println("No tienes oro suficiente."); else {oro-=8;pistaDisponible=true;System.out.println("Pista: la casilla del tesoro esta a distancia "+buscarDistancia(TESORO)+".");} }
        else System.out.println("Sigues tu camino.");
    }
    /** Comprueba si alcanza el oro y añade el objeto comprado. */
    private static void comprar(int precio,String articulo) {
        if(oro<precio) {System.out.println("No tienes oro suficiente.");return;}
        oro-=precio; if(articulo.equals("pocion")) pociones++; else escudo=true;
        System.out.println("Has comprado: "+articulo+".");
    }
    /** Busca un evento y devuelve los pasos que hay hasta llegar a él. */
    private static int buscarDistancia(char tipo) { for(int f=0;f<tamano;f++)for(int c=0;c<tamano;c++)if(mapa[f][c]==tipo)return Math.abs(f-fila)+Math.abs(c-columna);return -1; }
    /** Hace una pregunta: si acierta, gana oro; si falla, pierde vida. */
    private static void acertijo() {
        System.out.println("Acertijo: ¿Cuantos lados tiene un hexagono? 1) Cinco  2) Seis  3) Ocho");
        if(leerEntero("Respuesta: ",1,3)==2) {int premio=8+AZAR.nextInt(8);oro+=premio;System.out.println("¡Correcto! Ganas "+premio+" oro.");}
        else {recibirDano(1);System.out.println("Respuesta incorrecta: pierdes una vida.");}
    }
    /** Usa una poción para recuperar vidas, si todavía quedan pociones. */
    private static void usarObjeto() throws ObjetoNoDisponibleException {
        if(pociones<=0) throw new ObjetoNoDisponibleException("No tienes pociones.");
        if(vidas>=vidasIniciales) throw new ObjetoNoDisponibleException("Ya tienes todas tus vidas; guarda la pocion.");
        pociones--; int antes=vidas; vidas=Math.min(vidasIniciales,vidas+3);
        System.out.println("Usas una pocion y recuperas "+(vidas-antes)+" vidas.");
    }
    /** Resta vidas teniendo en cuenta si el jugador tiene un escudo. */
    private static void recibirDano(int cantidad) {
        if(escudo) {cantidad=Math.max(0,cantidad-2);escudo=false;System.out.println("El escudo absorbe parte del golpe.");}
        vidas=Math.max(0,vidas-cantidad);
    }
    /** Aplica el daño del veneno al final del turno y cuenta sus turnos. */
    private static void actualizarEstados() {
        if(veneno>0) {recibirDano(1);veneno--;System.out.println("El veneno te causa 1 de dano.");}
    }

    // Estas excepciones sirven para avisar de movimientos, objetos u opciones no válidos.
    private static class MovimientoInvalidoException extends Exception { MovimientoInvalidoException(String m){super(m);} }
    private static class ObjetoNoDisponibleException extends Exception { ObjetoNoDisponibleException(String m){super(m);} }
    private static class OpcionInvalidaException extends RuntimeException { OpcionInvalidaException(String m){super(m);} }
}


